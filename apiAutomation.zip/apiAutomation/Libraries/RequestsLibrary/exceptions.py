class UnknownStatusError(Exception):
    pass


class InvalidResponse(Exception):
    pass
